typedef struct{
	 char mat[20];
	 char arr[20];
	 char dep[20];
	 char jour[20];
	 char mois[20];
	 char annee[20];
	 char nom[20];
	 char prenom[20];
	 char hotel[20];
	 char voit[20];
	 char adress[20];
	 char prix[20];
}facture;


void afficher_temps(GtkWidget *liste);
void supp_facture(facture a);
void ajout_facture(facture b);
void afficher_recherch(GtkWidget *liste);
void recherche (char mat[20]);
