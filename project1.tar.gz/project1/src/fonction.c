#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonction.h"
#include "callbacks.h"


void afficher_temps(GtkWidget *liste)
{enum
{
	MAT,
	NOM,
	PRENOM,
	ADRESS,
	JOUR,
	MOIS,
	ANNEE,
	DEP,
	ARR,
	HOTEL,
	VOIT,
	PRIX,
	SELECTION,
};
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	 char mat[20];
	 char arr[20];
	 char dep[20];
	 char jour[20];
	 char mois[20];
	 char annee[20];
	 char nom[20];
	 char prenom[20];
	 char hotel[20];
	 char voit[20];
	 char adress[20];
	 char prix[20];
	 store=NULL;
	 
	 FILE *f;
	 
	 store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	 if(store==NULL)
	 {      
		 
	
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" matricule",renderer,"text",MAT,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" prenom",renderer,"text",PRENOM,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" adress",renderer,"text",ADRESS,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",MOIS,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		
		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",ANNEE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" depare",renderer,"text",DEP,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("  arrive",renderer,"text",ARR,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("  hotel",renderer,"text",HOTEL,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("  voiture",renderer,"text",VOIT,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("  prix",renderer,"text",PRIX,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		 renderer = gtk_cell_renderer_toggle_new ();
		column = gtk_tree_view_column_new_with_attributes(" select", renderer, "active",SELECTION, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		 
		 		 
		 store=gtk_list_store_new (13, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_BOOLEAN);
		f = fopen("src/factures.txt","r");
		if(f==NULL)
		{
			return;
		}
		else
		{f = fopen("src/factures.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",mat,nom,prenom,adress,jour,mois,annee,dep,arr,hotel,voit,prix)!=EOF)
		{
		gtk_list_store_append(store,&iter);
        gtk_list_store_set(store,&iter,MAT,mat,NOM,nom,PRENOM,prenom,ADRESS, adress,JOUR,jour,MOIS,mois,ANNEE,annee,DEP,dep,ARR,arr,HOTEL,hotel,VOIT,voit,PRIX,prix,-1);
        		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_signal_connect(G_OBJECT(renderer),"toggled", (GCallback)toggled_func,store);
		g_object_unref(store);
		}
	 }
}



void supp_facture(facture a){
FILE *f;
FILE *f1;
facture b;

f=fopen("src/factures.txt","r+");
f1=fopen("src/facturestemp.txt","w+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",b.mat,b.nom,b.prenom,b.adress,b.jour,b.mois,b.annee,b.dep,b.arr, b.hotel,b.voit,b.prix)!=EOF)
	{if (strcmp(b.mat,a.mat)!=0)
	fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s \n",b.mat,b.nom,b.prenom,b.adress,b.jour,b.mois,b.annee,b.dep,b.arr, b.hotel,b.voit,b.prix);
	}
fclose(f);
fclose(f1);
rename("src/facturestemp.txt","src/factures.txt");
}

void ajout_facture(facture b){
FILE *f;
f=fopen("src/factures.txt","a+");
fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",b.mat,b.nom,b.prenom,b.adress,b.jour,b.mois,b.annee,b.dep,b.arr, b.hotel,b.voit,b.prix);
fclose(f);
}

void afficher_recherch(GtkWidget *liste)
{enum
{
	MAT,
	NOM,
	PRENOM,
	ADRESS,
	JOUR,
	MOIS,
	ANNEE,
	DEP,
	ARR,
	HOTEL,
	VOIT,
	PRIX,
	SELECTION,
};
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	 char mat[20];
	 char arr[20];
	 char dep[20];
	 char jour[20];
	 char mois[20];
	 char annee[20];
	 char nom[20];
	 char prenom[20];
	 char hotel[20];
	 char voit[20];
	 char adress[20];
	 char prix[20];
	 store=NULL;
	 
	 FILE *f;
	 
	 store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	 if(store==NULL)
	 {      
		 
	
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" matricule",renderer,"text",MAT,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" prenom",renderer,"text",PRENOM,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" adress",renderer,"text",ADRESS,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",MOIS,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		
		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",ANNEE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" depare",renderer,"text",DEP,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("  arrive",renderer,"text",ARR,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("  hotel",renderer,"text",HOTEL,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("  voiture",renderer,"text",VOIT,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("  prix",renderer,"text",PRIX,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		 renderer = gtk_cell_renderer_toggle_new ();
		column = gtk_tree_view_column_new_with_attributes(" select", renderer, "active",SELECTION, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		 
		 		 
		 store=gtk_list_store_new (13, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_BOOLEAN);
		f = fopen("src/facturesrech.txt","r");
		if(f==NULL)
		{
			return;
		}
		else
		{f = fopen("src/facturesrech.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",mat,nom,prenom,adress,jour,mois,annee,dep,arr,hotel,voit,prix)!=EOF)
		{
		gtk_list_store_append(store,&iter);
        gtk_list_store_set(store,&iter,MAT,mat,NOM,nom,PRENOM,prenom,ADRESS, adress,JOUR,jour,MOIS,mois,ANNEE,annee,DEP,dep,ARR,arr,HOTEL,hotel,VOIT,voit,PRIX,prix,-1);
        		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_signal_connect(G_OBJECT(renderer),"toggled", (GCallback)toggled_func,store);
		g_object_unref(store);
		}
	 }
}

void recherche (char mat[20]){
facture b;
FILE *f;
FILE *f1;
char a[20];
f=fopen("src/factures.txt","r");
f1=fopen("src/temp.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",a,b.nom,b.prenom,b.adress,b.jour,b.mois,b.annee,b.dep,b.arr, b.hotel,b.voit,b.prix)!=EOF)
	{
if(strcmp(mat,a)==0)
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s \n",a,b.nom,b.prenom,b.adress,b.jour,b.mois,b.annee,b.dep,b.arr, b.hotel,b.voit,b.prix);
	}
fclose(f);
fclose(f1);
rename("src/temp.txt","src/facturesrech.txt");

}

