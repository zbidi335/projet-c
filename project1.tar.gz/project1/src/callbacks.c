#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window;
GtkWidget *treeview;
GtkWidget *input;
char cherche[20];

treeview=lookup_widget(button,"treeview1");
input=lookup_widget(button,"entry1");
strcpy(cherche,gtk_entry_get_text(GTK_ENTRY(input)));
recherche(cherche);
afficher_recherch(treeview);
	window=lookup_widget(button,"window1");
	gtk_widget_destroy(window);
	window=create_window1();
	gtk_widget_show(window);
	treeview=lookup_widget(window,"treeview1");
	afficher_recherch(treeview);

}
void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *paths, gpointer user_data)
{enum
{
	MAT,
	NOM,
	PRENOM,
	ADRESS,
	JOUR,
	MOIS,
	ANNEE,
	DEP,
	ARR,
	HOTEL,
	VOIT,
	PRIX,
	SELECTION,
};
    GtkTreeIter iter;
    GtkTreePath *path;
    FILE* f;
    	 gboolean boolean;
    	 gchar *mat;
	 gchar *arr;
	 gchar *dep;
	 gchar *jour;
	 gchar *mois;
	 gchar *annee;
	 gchar *nom;
	 gchar *prenom;
	 gchar *hotel;
	 gchar *voit;
	 gchar *adress;
	 gchar *prix;
    
    path = gtk_tree_path_new_from_string (paths);
    gtk_tree_model_get_iter (GTK_TREE_MODEL (user_data),&iter,path);
    gtk_tree_model_get (GTK_TREE_MODEL (user_data),&iter,SELECTION,&boolean,MAT,&mat,NOM,&nom,PRENOM,&prenom,ADRESS, &adress,JOUR,&jour,MOIS,&mois,ANNEE,&annee,DEP,&dep,ARR,&arr,HOTEL,&hotel,VOIT,&voit,PRIX,&prix,-1);
    gtk_list_store_set (user_data, &iter,SELECTION, !boolean,-1);
    if (!boolean) { //creation de la date dans un fichier tmp
    f=fopen("src/tempss.txt","a+");
    fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",mat,nom,prenom,adress,jour,mois,annee,dep,arr,hotel,voit,prix);
    fclose(f);
}
}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window;

window=lookup_widget(button,"window1");
gtk_widget_hide(window);
window=create_window2();
gtk_widget_show(window);
}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window;
GtkWidget *treeview;
FILE *f;
facture b;

f=fopen("src/tempss.txt","r");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",b.mat,b.nom,b.prenom,b.adress,b.jour,b.mois,b.annee,b.dep,b.arr, b.hotel,b.voit,b.prix)!=EOF)
	{
	supp_facture(b);
	}
	window=lookup_widget(button,"window1");
	gtk_widget_destroy(window);
	window=create_window1();
	gtk_widget_show(window);
	treeview=lookup_widget(window,"treeview1");
	afficher_temps(treeview);
fclose(f);
remove("src/tempss");

}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *treeview;

	window=lookup_widget(button,"window2");
	gtk_widget_destroy(window);
	window=create_window1();
	gtk_widget_show(window);
  	treeview=lookup_widget(window,"treeview1");
  	afficher_temps(treeview);


}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window;
GtkWidget *treeview;
GtkWidget *depar;
GtkWidget *arrive;
GtkWidget *input;
GtkWidget *boolean;
facture a;
int jour,mois,annee,i;
gboolean avion;
gboolean hotell;
gboolean voit;
input=lookup_widget(button,"entry2");
strcpy(a.mat,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"entry3");
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"entry4");
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"entry5");
strcpy(a.adress,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"spinbutton1");
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
sprintf(a.jour, "%d", jour); 

input=lookup_widget(button,"spinbutton2");
mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
sprintf(a.mois, "%d", mois); 

input=lookup_widget(button,"spinbutton3");
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
sprintf(a.annee, "%d", annee); 

boolean=lookup_widget(button,"checkbutton2");
avion=gtk_toggle_button_get_active (boolean);

depar=lookup_widget(button,"combobox2");
arrive=lookup_widget(button,"combobox3");
if (avion)
{
strcpy(a.dep,gtk_combo_box_get_active_text(GTK_COMBO_BOX(depar)));
strcpy(a.arr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(arrive)));
}
else{
strcpy(a.dep,"-");
strcpy(a.arr,"-");
}

boolean=lookup_widget(button,"checkbutton1");
hotell=gtk_toggle_button_get_active (boolean);
input=lookup_widget(button,"combobox1");

if(hotell)
	{
strcpy(a.hotel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
	}
else{
strcpy(a.hotel,"-");
}
boolean=lookup_widget(button,"checkbutton3");
voit=gtk_toggle_button_get_active (boolean);

if(voit)
	{
strcpy(a.voit,"oui");
	}
else{
strcpy(a.voit,"NO");
}	

input=lookup_widget(button,"entry11");
strcpy(a.prix,gtk_entry_get_text(GTK_ENTRY(input)));
ajout_facture(a);
	window=lookup_widget(button,"window2");
	gtk_widget_destroy(window);
	window=create_window1();
	gtk_widget_show(window);
	treeview=lookup_widget(window,"treeview1");
	afficher_temps(treeview);

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{gchar *MATRICULE;	
gchar *NOM; 
gchar *PRENOM;
gchar *JOUR;
gchar *MOIS;
gchar *ANNEE;
gchar *ADRESSE;
gchar *DEP;
gchar *ARR;
gchar *HOTEL;
gchar *VOIT;
gchar *PRIX;
GtkWidget *window;
GtkWidget *window3;
GtkWidget *current;
GtkTreeIter iter;
GtkWidget *matricule;
GtkWidget *nom;
GtkWidget *dep;
GtkWidget *arr;
GtkWidget *prenom;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *anne;
GtkWidget *add;
GtkWidget *hotel;
GtkWidget *hotell;
GtkWidget *avion;
GtkWidget *voiture;
GtkWidget *prix;

char prixx[20];
int day,month,year;

window=lookup_widget(treeview,"window1");
gtk_widget_hide(window);
window3=create_window3(); 
gtk_widget_show(window3);
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&MATRICULE,1,&NOM,2,&PRENOM,3,&ADRESSE,4,&JOUR,5,&MOIS,6,&ANNEE ,7,&DEP,8,&ARR,9,&HOTEL,10,&VOIT,11,&PRIX,-1);}

matricule=lookup_widget(window3,"entry6");
nom=lookup_widget(window3,"entry7");
prenom=lookup_widget(window3,"entry8");
add=lookup_widget(window3,"entry9");

jour=lookup_widget(window3, "spinbutton4");
mois=lookup_widget(window3, "spinbutton5");
anne=lookup_widget(window3, "spinbutton6");

avion=lookup_widget(window3, "checkbutton6");
hotel=lookup_widget(window3, "checkbutton4");
voiture=lookup_widget(window3, "checkbutton5");

dep=lookup_widget(window3, "combobox6");
arr=lookup_widget(window3, "combobox4");
hotell=lookup_widget(window3, "combobox5");
prix=lookup_widget(window3, "entry10");
if(strcmp(DEP,"-")!=0)
	{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(avion),TRUE);
	if(strcmp(DEP,"tunis")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(dep),0);
	else if(strcmp(DEP,"maroc")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(dep),1);
	else if(strcmp(DEP,"istanbul")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(dep),2);
	else if(strcmp(DEP,"france")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(dep),3);
	if(strcmp(ARR,"tunis")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(arr),0);
	else if(strcmp(ARR,"maroc")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(arr),1);
	else if(strcmp(ARR,"istanbul")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(arr),2);
	else if(strcmp(ARR,"tunis")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(arr),3);
	}
if(strcmp(HOTEL,"-")!=0)
	{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(hotel),TRUE);
	if(strcmp(HOTEL,"hotel1")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(hotell),0);
	}
if(strcmp(VOIT,"oui")==0)
	{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(voiture),TRUE);
	}
sscanf( JOUR, "%d",&day);
sscanf( MOIS, "%d",&month);
sscanf( ANNEE, "%d",&year);

gtk_entry_set_text(GTK_ENTRY(matricule),MATRICULE);
gtk_entry_set_text(GTK_ENTRY(nom),NOM);
gtk_entry_set_text(GTK_ENTRY(prenom),PRENOM);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour),day);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois),month);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(anne),year);
gtk_entry_set_text(GTK_ENTRY(add),ADRESSE);
gtk_entry_set_text(GTK_ENTRY(prix),PRIX);

}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window;
GtkWidget *treeview;
GtkWidget *depar;
GtkWidget *arrive;
GtkWidget *input;
GtkWidget *boolean;
facture a;
int jour,mois,annee,i;
gboolean avion;
gboolean hotell;
gboolean voit;
input=lookup_widget(button,"entry6");
strcpy(a.mat,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"entry7");
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"entry8");
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"entry9");
strcpy(a.adress,gtk_entry_get_text(GTK_ENTRY(input)));

input=lookup_widget(button,"spinbutton4");
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
sprintf(a.jour, "%d", jour); 

input=lookup_widget(button,"spinbutton5");
mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
sprintf(a.mois, "%d", mois); 

input=lookup_widget(button,"spinbutton6");
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));
sprintf(a.annee, "%d", annee); 

boolean=lookup_widget(button,"checkbutton6");
avion=gtk_toggle_button_get_active (boolean);

depar=lookup_widget(button,"combobox6");
arrive=lookup_widget(button,"combobox4");
if (avion)
{
strcpy(a.dep,gtk_combo_box_get_active_text(GTK_COMBO_BOX(depar)));
strcpy(a.arr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(arrive)));
}
else{
strcpy(a.dep,"-");
strcpy(a.arr,"-");
}

boolean=lookup_widget(button,"checkbutton4");
hotell=gtk_toggle_button_get_active (boolean);
input=lookup_widget(button,"combobox5");

if(hotell)
	{
strcpy(a.hotel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
	}
else{
strcpy(a.hotel,"-");
}
boolean=lookup_widget(button,"checkbutton5");
voit=gtk_toggle_button_get_active (boolean);

if(voit)
	{
strcpy(a.voit,"oui");
	}
else{
strcpy(a.voit,"NO");
}	

input=lookup_widget(button,"entry10");
strcpy(a.prix,gtk_entry_get_text(GTK_ENTRY(input)));
supp_facture(a);
ajout_facture(a);

	window=lookup_widget(button,"window3");
	gtk_widget_destroy(window);
	window=create_window1();
	gtk_widget_show(window);
	treeview=lookup_widget(window,"treeview1");
	afficher_temps(treeview);


}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *treeview;

	window=lookup_widget(button,"window3");
	gtk_widget_destroy(window);
	window=create_window1();
	gtk_widget_show(window);
  	treeview=lookup_widget(window,"treeview1");
  	afficher_temps(treeview);


}

